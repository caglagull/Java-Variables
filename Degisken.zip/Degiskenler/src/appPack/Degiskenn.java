package appPack;

public class Degiskenn {

	
	public static void main(String[] args) {
		
		
		int tel=444_67_444;
		System.out.println(tel);
		int ogrNo=10_90_406_22;
		System.out.println(ogrNo);
		int sonuc=56_4+12_8;
		System.out.println(sonuc);
		float sayi=47_6;
		System.out.println(sayi);
		
		String a="4";
		Integer b=Integer.valueOf(a);
		System.out.println(a);
        Integer c=Integer.parseInt(a);
        String d="7";
        Integer e=Integer.valueOf(d);
        Integer f=Integer.parseInt(d);
        System.out.println(d);
        
        int z=9;
        String x=String.valueOf(z);
        String y=Integer.toString(z);
System.out.println(z);
}
}